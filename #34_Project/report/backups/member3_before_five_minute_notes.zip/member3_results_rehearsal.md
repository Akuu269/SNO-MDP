# Member 3 — results explanation: five to six minutes

**Four results slides, followed by a separate Thank You slide. Aim for about 5:40, including brief pauses and the dashboard handoff.**

Speak the paragraphs below. The italic instructions are reminders about where to point; do not read them aloud. Technical terms are explained as they first appear.

## Integrated presentation slide map

The combined presentation has 15 slides. Members 1 and 2 retain slides 1–8. Your original Slide 1–5 text and timing cues below are preserved exactly; those cues refer to the standalone results deck. The two added explanations extend that rehearsal.

| Presentation slide | Rehearsal section |
|---|---|
| 9 | Added experimental-design explanation |
| 10 | Your Slide 1 — Reward |
| 11 | Your Slide 2 — Safety and reward |
| 12 | Your Slide 3 — Noise robustness |
| 13 | Your Slide 4 — Exploration budget |
| 14 | Added saved-dashboard explanation |
| 15 | Your Slide 5 — Thank You and Srinivas handoff |

## slide 11 : Experimental design

*Do not speak: point to the six maps, two observation seeds, three noise factors, and 160-action budget. Then indicate the 192-run total and the matched confidence-setting comparison.*

Before showing the results, let me explain how we made the comparison fair. We selected the safety confidence setting using development data, then froze the settings before evaluating six fresh maps. Frozen means we did not adjust the settings after seeing the final outcomes.

Each map uses two observation seeds, which produce different sensor-noise realizations. That gives twelve runs for each method at one noise setting. We repeat the learners under three assumptions about sensor noise: underestimated, correctly specified, and overestimated. The actual sensor noise stays fixed.

Every run has the same budget of 160 physical actions. This includes travel, safety exploration, and reward optimization, so a method cannot improve its score simply by taking more actions.

The total is 192 runs: five learner conditions, multiplied by six maps, two observation seeds, and three noise assumptions, gives 180. We add twelve oracle reference runs. The oracle knows the true environment and is evaluated once for each map and observation-seed pair.

For the certificate comparison, both methods use a safety confidence multiplier of four. One retains earlier safety permissions; the other rechecks them. Holding this setting fixed helps us separate certificate handling from the effect of increasing the confidence multiplier. 
In next slide, will show the reward graph.

## Slide 12 — Reward across the same action budget

In this graph presenting, We tested six generated maps, using two separate sets of noisy sensor observations on each map. Every run received 160 actions. That gives twelve runs per condition. 

The horizontal axis shows actions taken. The vertical axis shows discounted return: the reward collected, with rewards received later given slightly less weight.

The grey curve is the basic Safe Near-Optimal Markov Decision Process method, labelled SNO-MDP. The teal curve adds Early Stopping of Exploration of Safety, labelled ES2. This lets the rover switch from mapping safety to optimizing reward.

With the safety confidence multiplier set to two, the method with early stopping earns about 177.compared with 158.93 for the basic method. The two versions using a multiplier of four earn about 157 and 155 optimised reward. I will explain this multiplier in coming slide.

The dashed oracle curve knows the true environment, so it is a privileged reference.

The first observation is higher average reward with early stopping in this comparison.

## Slide 13 — Safety and reward must be read together

Don't speak : *Approximate position: 1:30–3:00. Point to the left error bars, then the unsafe-action bars on the right. Compare the two conditions with a safety confidence multiplier of four.*

This Bar-chart puts reward and safety together. The left bars show average return. The vertical lines show standard deviation, labelled SD: how much the six map averages differ. Longer lines mean more variation between maps, not a confidence intervals.

The right panel counts unsafe actions: moves that violate the experiment's terrain safety limit. With the safety confidence multiplier at two, the average is 2.5 per run: thirty unsafe actions across twelve runs. It is an action count, not a percentage.

The letter c in the labels means safety confidence multiplier. It widens the uncertainty margin used to judge safety. Increasing it from two to four requires stronger evidence before allowing movement, making the rover more conservative.

The two versions at four also handle past safety decisions differently. Retained keeps earlier safety permissions. Revalidated checks them against the current model. Comparing these two holds the multiplier fixed.

Both record zero violations here, so this slide alone does not show an additional safety benefit from revalidation. Its average return is also slightly lower. 

So now, The next experiment checks what happens when our noise assumption is wrong.

## Slide 14 — Robustness when sensor noise is misspecified

Don't speak : *Approximate position: 3:00–4:20. Trace the three noise assumptions from left to right, then point to the totals in the side panel.*

A rover's sensor model may underestimate measurement noise. Here we keep the actual sensor noise fixed and change only what the model assumes about altitude measurements.

On the horizontal axis, 0.5 means the model assumes half the actual noise standard deviation: it trusts measurements too much. 
1 means the assumption matches reality. 2 means the model assumes twice the actual noise standard deviation.

The vertical axis shows average unsafe actions per run. Across all three settings. 

The two violations in the retained version at four occur in one run that underestimates noise. That is where the comparison separates.

Revalidation therefore records fewer violations in these tested conditions. Zero observed violations is encouraging, but six maps cannot establish safety in every environment.

## Slide 15 — ES2 shifts actions from exploration to reward

Don't speak : *Approximate position: 4:20–5:30. Point to the 160-action reference line, then compare the first two bars and the 42.58-action difference.*

This is final bar-chart shows why early stopping matters. The vertical axis counts actions spent exploring safety, and the dashed line marks our shared limit of 160 actions.

Compare the first two bars. Both use the same safety confidence multiplier of two and retain past safety permissions. The basic method spends all 160 actions exploring. With early stopping, that average falls to 117.42.

The rover already collects rewards while exploring; early stopping changes its priority rather than switching reward collection on for the first time.

The two methods using a multiplier of four spend longer exploring, showing how conservative safety settings affect this benefit.

Every run still executes 160 actions, so this is a change in budget allocation, not evidence of faster computation. Together, the graphs show why we must assess reward, safety, and exploration together.

## Slide 16 — Saved dashboard evidence (presentation slide 14)


In short time : This is our SNO-MDP dashboard , where we displaying the rover move with 20 * 20 Gym-safety data. and their result output. 

*Do not speak: identify this as a saved replay. Point to step 97 and one violation, then the pre-move lower confidence bound and safety threshold on the right.*

This slide connects the aggregate results to one decision in the dashboard. It is saved evidence from a completed source demonstration, not a live experiment. The screenshot shows step 97 on map 100 with observation seed 3000, where the violation count has reached one.

To understand that event, look at the information before the move, at step 96. The current lower confidence bound, abbreviated LCB on the slide, is approximately minus 0.280632. The safety threshold is minus 0.25. Because the bound is below the threshold, the current model does not provide enough evidence to certify that move as safe.

However, the source method retains an earlier safety permission. That retained permission still allows the upward move. The executed transition then violates the true safety limit, which is why the counter becomes one at step 97.

The low confidence bound alone is not proof that a move is unsafe; it means the current safety certificate is unsupported. The recorded violation is the separate outcome of executing this particular move.

This example illustrates the reason for rechecking earlier permissions against the current model. It is one trajectory, whereas the previous graphs combine multiple maps and runs. The screenshot also gives us saved evidence if the browser is unavailable. Srinivas will explain the interactive replay and experiments in the live dashboard demonstration.

## Slide 16 & 17 — Thank You

*Approximate position: 5:30–5:40. Pause, thank the audience, and hand over to Member 4.*

Thank you. Srinivas will now demonstrate the dashboard and show how we inspect individual runs and compare experiments.

---

**Rehearsal tip:** pause after each graph's main result and give the audience a moment to look at it. Practise once aloud with a timer; the 5:40–6:00 buffer allows for those pauses.
