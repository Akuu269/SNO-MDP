# Member 3 — detailed results speaker notes

Your responsibility is the experimental design, graphs, tables, and defensible conclusions. Member 4 presents the dashboard. You do not need to repeat Members 1–2's algorithm derivations.

**Four results slides plus a separate Thank You slide: five slides total. The expanded explanation targets 5:40, within five to six minutes including handoff.** Use the rehearsal script for the spoken explanation; the extra material below supports preparation and questions.

[Your PowerPoint](member3_results.pptx) · [PDF](member3_results.pdf) · [Browser deck](member3_results.html) · [Expanded rehearsal script](member3_results_rehearsal.md)

Results slides 1–3 correspond to the team's slides 10–12. Results slide 4 adds the measured ES2 exploration-budget comparison. Study design and full tables remain here as preparation material. Slide 5 is Thank You and the dashboard handoff.

## Your presentation route

| Time | Slide | Main message |
|---|---|---|
| 0:00–1:30 | 1 — Reward trajectories | State sample counts; read axes and compare raw discounted returns |
| 1:30–3:00 | 2 — Safety–reward bars | Explain standard deviation, the safety confidence multiplier, and unsafe actions |
| 3:00–4:20 | 3 — Noise robustness | Explain the 98 / 2 / 0 totals and their limits |
| 4:20–5:30 | 4 — Early stopping and the exploration budget | Explain the 42.58 actions reallocated within the fixed budget |
| 5:30–5:40 | 5 — Thank You | Hand over to Member 4 for the dashboard |
| 5:40–6:00 | Buffer | Allow for pauses while pointing at graphs |

For each chart, follow **axes → conditions → observation → limitation**. Point to one feature while explaining it. Do not read every legend entry or every number.

## Slide 1 — Reward across the same action budget

### Spoken explanation

> Let me connect the method to what we actually observed. We tested six generated maps, using two separate sets of noisy sensor observations on each map. Every run received 160 actions. That gives twelve runs per condition. In the first two slides, assumed sensor noise matches actual sensor noise.
>
> The horizontal axis shows actions taken. The vertical axis shows discounted return: the reward collected, with rewards received later given slightly less weight.
>
> The grey curve is the basic Safe Near-Optimal Markov Decision Process method, labelled SNO-MDP. The teal curve adds Early Stopping of Exploration of Safety, labelled ES2. This lets the rover switch from mapping safety to optimizing reward.
>
> With the safety confidence multiplier set to two, the method with early stopping earns about 177.56, compared with 158.93 for the basic method. The two versions using a multiplier of four earn about 157 and 155. I will explain this multiplier next.
>
> The dashed oracle curve knows the true environment, so it is a privileged reference.
>
> The first observation is higher average reward with early stopping in this comparison. Let us now check whether those rewards were earned safely.

### Where to point

Point first to the horizontal 0–160 action axis, then the return axis. Identify the dashed oracle and compare the final values of basic, source ES2, and the two c=4 variants. Do not interpret a bend as a shared phase-switch step.

### Detailed understanding

PURPOSE: read the curve axes and information advantage correctly.

At step t, the curve is the mean discounted return accumulated through t physical actions. The initial
state reward is not credited as a free action: the recorded curve starts at zero. Reward is the true
arrival reward scored by the evaluator; noisy readings train the learner. All travel, stays, and
exploration moves consume the same 160-action budget and contribute their actual arrival rewards.

Discounted return is G_T = sum(t=1..T) gamma^(t-1) r(s_t), with gamma=0.99. It differs from raw cumulative
reward and from a normalized reward ratio. A score of 177.56 is not 177.56 percent and is not the paper's
Mars reward score.

Read the five curves by their labels. Grey is basic SNO-MDP c=2; teal is retained ES2 c=2; gold is retained
ES2 c=4; purple is revalidated ES2 c=4; dashed dark is oracle. This plot shows means only. Variability is
provided by the next slide. A single bend in an averaged curve is not one common ES2 switching step.

At matched noise SafeMDP and basic SNO-MDP have identical mean return here because the basic method never
switches within the 160-action horizon and uses the same exploration controller. That equality is specific
to this subset, not a universal equivalence.

The oracle has access to the true fields and uses a true-safe planning reference. It is an infinite-horizon
policy rolled out for the finite budget, so do not call it a universal finite-horizon return upper bound.

### Safest conclusion

Source ES2 has higher nominal mean return here; that alone does not establish better constrained performance.

### Transition

Reward is only one side of a safe-RL evaluation; the next graph puts it beside actual violations.

## Slide 2 — Safety and reward must be read together

### Spoken explanation

> This slide puts reward and safety together. The left bars show average return. The vertical lines show standard deviation, labelled SD: how much the six map averages differ. Longer lines mean more variation between maps; they are not confidence intervals.
>
> The right panel counts unsafe actions: moves that violate the experiment's terrain safety limit. With the safety confidence multiplier at two, the average is 2.5 per run: thirty unsafe actions across twelve runs. It is an action count, not a percentage. Both versions using a multiplier of four record zero here.
>
> The letter c in the labels means safety confidence multiplier. It widens the uncertainty margin used to judge safety. Increasing it from two to four requires stronger evidence before allowing movement, making the rover more conservative.
>
> The two versions at four also handle past safety decisions differently. Retained keeps earlier safety permissions. Revalidated checks them against the current model. Comparing these two holds the multiplier fixed.
>
> Both record zero violations here, so this slide alone does not show an additional safety benefit from revalidation. Its average return is also slightly lower. The next experiment checks what happens when our noise assumption is wrong.

### Where to point

Point to the left error bars, explain their denominator, then move to the right panel's 2.500 / 0 / 0 values. Finish by comparing the two c=4 conditions, not only c=2 against the extension.

### Detailed understanding

PURPOSE: explain the trade-off and avoid attributing confidence effects to the extension.

The left panel uses three ES2 conditions at factor 1. The return means are 177.5552, 157.1841, and 155.3056.
The map SDs are 80.0405, 55.9737, and 55.0548. Each SD describes six per-map means, after averaging the
two observation seeds. It is not a standard error, confidence interval, or proof of equal performance.

The right panel counts executed constraint violations, not false beliefs. Source ES2 records 30 unsafe
actions in 12 runs, so its mean is 30/12=2.5. Ten of those 12 runs have at least one violation, giving
an unsafe-run fraction of 83.33%. These quantities have different denominators. Both c=4 profiles have
zero unsafe actions at matched noise. All three complete their scheduled horizon.

Retained c=2 versus retained c=4 changes the safety multiplier while holding the certificate rule.
Retained c=4 versus revalidated c=4 changes certificate handling while holding confidence.
Retained c=2 versus revalidated c=4 changes both. Read the controls before claiming causality.

The extension's nominal mean return is about 1.88 below the c=4 retained control. We have not performed
a formal significance/equivalence test. Overlapping unpaired SD bars alone do not answer that question.
A paired analysis should compare matched maps/observations and retain the six-map hierarchy.

Zero executed violations is not automatically zero false certificates or a theorem. The actual nominal
c=4 records also show zero peak false certificates, but that extra observation must not be generalized
to arbitrary noise, kernels, or environments.

### Safest conclusion

At matched noise both c=4 conditions record zero violations, so this subset alone does not show an extra violation reduction from revalidation.

### Transition

The same-c methods separate under underestimated noise, which motivates the next robustness plot.

## Slide 3 — Robustness when sensor noise is misspecified

### Spoken explanation

> A rover's sensor model may underestimate measurement noise. Here we keep the actual sensor noise fixed and change only what the model assumes about altitude measurements.
>
> On the horizontal axis, one-half means the model assumes half the actual noise standard deviation: it trusts measurements too much. One means the assumption matches reality. Two means the model assumes twice the actual noise standard deviation.
>
> The vertical axis shows average unsafe actions per run. Across all three settings, there are thirty-six runs for each method. The totals in the side panel are ninety-eight unsafe actions with retained permissions and a multiplier of two, two with retained permissions and a multiplier of four, and zero with revalidation and a multiplier of four.
>
> The two violations in the retained version at four occur in one run that underestimates noise. That is where the comparison separates.
>
> Revalidation therefore records fewer violations in these tested conditions. Zero observed violations is encouraging, but six maps cannot establish safety in every environment.

### Where to point

Read the three x-axis factors as noise assumptions, not different terrains or different actual sensor noises. Explain the near-zero gold point at factor 0.5, then the side-panel totals across all factors.

### Detailed understanding

PURPOSE: show the condition where the same-c control separates from revalidation.

The actual altitude and reward sensor STDs remain 0.001. The x-axis changes the altitude GP's assumption:
factor 0.5 means assumed altitude STD 0.0005; factor 1 means 0.001; factor 2 means 0.002.
The reward GP uses the specified reward noise, without this factor.

For retained c=2 the unsafe-action totals are 58, 30, and 10 at factors 0.5, 1, and 2, giving 98 overall.
For retained c=4 they are 2, 0, and 0. For revalidated c=4 they are 0, 0, and 0.
The graph divides each factor's totals by 12 runs, so 58/12=4.8333, 30/12=2.5, and 10/12=0.8333.
The side panel gives totals across all 36 runs per profile; do not confuse those with per-run means.

Both retained-c=4 violations occur in one factor-0.5 run. This is limited evidence, not a robust estimate
of rare-event probabilities. A practical interval can be wrong; retaining an old acceptance can matter
later. Current-LCB revalidation enforces current model support, which can itself be wrong.

All 192 cases completed, with zero model/setup/planning/region-loss failures. The full inventory still
contains 384 unsafe actions because it also includes SafeMDP and basic SNO-MDP. Completion is separate
from action safety; never summarize it as 'no failures, therefore no violations.'

Next explain the exploration-budget result. Keep this plot's conclusion limited to the tested noise
conditions and practical confidence settings.

### Safest conclusion

Across tested noise factors, revalidation records zero unsafe actions versus two for the matched-c retained control; this is finite, limited evidence.

### Transition

The final result examines the other purpose of ES2: stopping safety exploration earlier to leave more actions for reward optimization.

## Slide 4 — ES2 shifts actions from exploration to reward

### Spoken explanation

> The final graph shows why early stopping matters. The vertical axis counts actions spent exploring safety, and the dashed line marks our shared limit of 160 actions.
>
> Compare the first two bars. Both use the same safety confidence multiplier of two and retain past safety permissions. The basic method spends all 160 actions exploring. With early stopping, that average falls to 117.42.
>
> The difference is 42.58 actions, or 26.6 percent of the budget, available for reward optimization. The rover already collects rewards while exploring; early stopping changes its priority rather than switching reward collection on for the first time.
>
> The two methods using a multiplier of four spend longer exploring, showing how conservative safety settings affect this benefit.
>
> Every run still executes 160 actions, so this is a change in budget allocation, not evidence of faster computation. Together, the graphs show why we must assess reward, safety, and exploration together.

### Where to point

Point to the dashed 160-action horizon, then the basic c=2 and ES2 c=2 bars. Explain 160.00 minus 117.42 equals 42.58 actions reallocated. Briefly identify the two c=4 bars as different confidence settings, rather than treating them as the same stopping comparison.

### Detailed understanding

PURPOSE: explain the measured benefit of early stopping without claiming fewer total actions.

The horizontal categories are basic SNO-MDP c=2, retained ES2 c=2, retained ES2 c=4, and revalidated
ES2 c=4. The vertical axis is mean physical actions assigned to safety exploration at matched noise.
There are 12 runs per condition on six maps. The dashed line marks the common 160-action horizon.

The means are 160.00, 117.42, 149.33, and 153.75. The controlled comparison for early stopping is basic
c=2 versus retained ES2 c=2: the confidence multiplier and retained-certificate rule are held fixed.
The difference is 42.58 actions, or 26.6% of the fixed budget. The remaining actions are available for
the reward-optimization phase. Exploration and travel already earn reward, so this is not a change
from zero reward to positive reward and does not directly quantify the return gain.

Source ES2 triggers in 11/12 cases; each c=4 ES2 variant triggers in 2/12. The more conservative
confidence setting changes the stopping behavior. Do not attribute c=2-versus-c=4 differences solely
to the certificate extension. A mean is not the switching step of every individual trajectory.

Every run executes 160 physical actions. This result does not establish lower wall-clock cost, fewer
GP updates, or a five-fold speedup. Source c=2 also has violations, as shown earlier; earlier stopping
alone does not establish better constrained performance. End with the measured benefit and trade-off,
then use the separate Thank You slide to hand over to Member 4.

### Safest conclusion

In the matched c=2 comparison, ES2 reallocates 26.6% of the common action budget from safety exploration to reward optimization; this is not fewer total actions or a measured runtime speedup.

### Transition

These results show the budget benefit alongside the safety–reward trade-off. Member 4 will now demonstrate the dashboard.

## Slide 5 — Thank You

> Thank you. Member four will now demonstrate the dashboard and show how we inspect individual runs and compare experiments.

Keep the closing brief and let Member 4 begin the dashboard demonstration. Do not introduce another result on this slide.

## Study context — preparation only

PURPOSE: establish a fair denominator before discussing outcomes.

192 = (5 learner conditions × 6 maps × 2 observations × 3 noise factors) + (6 maps × 2 oracle observations).
The five learners are SafeMDP, basic SNO-MDP, source ES2 c=2, retained ES2 c=4, and revalidated ES2 c=4.
The oracle appears once per map/observation pair, not once per assumed-noise factor.

Each ES2 profile has 36 runs across all noise factors and 12 at factor 1. Those 12 runs come from six
independent maps with two observation repeats per map. The 20×20 size and 160-action budget stay fixed.
Map seeds are 100–105; observation seeds are 3000 and 3001.

The source and confidence profiles retain historical certificates. The extension revalidates current
bounds, while preserving supplied initial certificates. Compare the two c=4 profiles to isolate this rule.
Development data selected c=4 before the held-out evaluation. Do not describe it as tuned on these results.

Map-mean aggregation gives each terrain equal weight. A complete experiment run is not an independent
terrain, and repeated observations/policies share information structure. Use the six maps as the
independent experimental units when discussing map variability.

## Metric dictionary — know the denominator

| Metric | Meaning | Common mistake |
|---|---|---|
| Discounted return | True arrival rewards weighted by gamma^(t−1), including exploration/travel | Calling it a percentage or normalized score |
| Cumulative reward | Unweighted sum of the same arrival rewards | Assuming it must rank policies identically to discounted return |
| Unsafe actions / run | Mean number of executed movements with g(s,a) < −0.25 | Treating 2.5 as 2.5% or 2.5 unsafe runs |
| Unsafe-run fraction | Fraction of runs with at least one executed violation, averaged by map | Confusing it with the number of violating actions |
| Failed run | Setup/model/planning/region-loss stop rather than normal horizon completion | Assuming an unsafe move necessarily terminates the simulation |
| False certificates | Evaluator-detected incorrect permissions, possibly never executed | Treating every false permission as a physical accident |
| ES2 trigger fraction | Fraction of cases where the auxiliary stopping condition triggered | Treating a trigger alone as proof of better reward or safety |
| Mean exploration actions | Actions assigned to safety exploration within the common budget | Describing a smaller value as less total execution or measured CPU time |
| Map SD | Sample SD of six map means after averaging observation repeats | Calling it a confidence interval or SD of 192 independent trials |

## Worked arithmetic you can explain

### Why 192 cases?

Five learner conditions × six maps × two observation seeds × three noise factors = 180 learner cases. Add 12 oracle references, once per map/observation pair, to obtain 192. A single ES2 profile has 36 cases across all factors, or 12 at matched noise.

### What does 2.500 unsafe actions per run mean?

At matched noise, retained c=2 ES2 records 30 violating actions in 12 runs: 30/12 = 2.5. Ten of the 12 runs have at least one violation: 10/12 = 83.33%. Both statistics are correct and measure different things.

### How are the return mean and SD calculated?

For each map m, average its two observation-seed returns: Y_m = (G_m,3000 + G_m,3001)/2. Then mean return = sum(Y_m)/6. Map SD = sqrt(sum((Y_m − mean)^2)/(6−1)).

In this balanced study, averaging all 12 returns gives the same overall mean. It does not give the same uncertainty calculation as using six map means. Repeated policies and observations are correlated; 192 is not the sample size for a single condition.

### How do the noise factors translate into GP assumptions?

| Factor | Actual altitude STD | Assumed altitude STD | Interpretation |
|---|---:|---:|---|
| 0.5 | 0.001 | 0.0005 | Underestimate altitude measurement noise |
| 1 | 0.001 | 0.001 | Correctly specified |
| 2 | 0.001 | 0.002 | Overestimate altitude measurement noise |

Reward noise stays correctly specified at 0.001. The factor does not resample the map or deliberately add more actual sensor noise.

### How much exploration was reallocated?

Basic c=2 averages 160.00 exploration actions; source ES2 c=2 averages 117.42. The difference is 42.58 actions, or 26.6% of the budget, reallocated to reward optimization on average. Every case still uses 160 physical actions. No wall-clock speedup follows from this arithmetic.

Source ES2 triggers in 11/12 matched-noise cases. Each c=4 variant triggers in 2/12. Those different rates reflect different confidence/certificate conditions; compare basic c=2 with source ES2 c=2 to isolate the stopping change.

## Full nominal result table — preparation only

Factor 1 only. Every row has 12 runs / six maps / horizon 160. All failed-run fractions are zero.

| Profile / method | Return mean ± map SD | Unsafe actions / run | Unsafe runs | ES2 triggered | Exploration actions |
|---|---:|---:|---:|---:|---:|
| oracle / oracle | 268.96 ± 74.68 | 0.000 | 0.00% | 0.00% | 0.00 |
| source / safemdp | 158.93 ± 69.51 | 3.417 | 83.33% | 0.00% | 160.00 |
| source / sno_basic | 158.93 ± 69.51 | 3.417 | 83.33% | 0.00% | 160.00 |
| source / sno_es2 | 177.56 ± 80.04 | 2.500 | 83.33% | 91.67% | 117.42 |
| confidence / sno_es2 | 157.18 ± 55.97 | 0.000 | 0.00% | 16.67% | 149.33 |
| revalidated / sno_es2 | 155.31 ± 55.05 | 0.000 | 0.00% | 16.67% | 153.75 |

## Every ES2 noise condition — preparation only

Each row has 12 runs / six maps. Read totals and unsafe-run counts separately.

| Factor | ES2 profile | Return ± map SD | Unsafe / run | Unsafe actions total | Runs with violation | ES2 triggers |
|---|---|---:|---:|---:|---:|---:|
| 0.5 | ES2 retained c=2 | 173.00 ± 72.81 | 4.833 | 58 | 12/12 | 12/12 |
| 0.5 | ES2 retained c=4 | 178.57 ± 95.11 | 0.167 | 2 | 1/12 | 4/12 |
| 0.5 | ES2 revalidated c=4 | 175.88 ± 95.92 | 0.000 | 0 | 0/12 | 0/12 |
| 1 | ES2 retained c=2 | 177.56 ± 80.04 | 2.500 | 30 | 10/12 | 11/12 |
| 1 | ES2 retained c=4 | 157.18 ± 55.97 | 0.000 | 0 | 0/12 | 2/12 |
| 1 | ES2 revalidated c=4 | 155.31 ± 55.05 | 0.000 | 0 | 0/12 | 2/12 |
| 2 | ES2 retained c=2 | 162.82 ± 52.45 | 0.833 | 10 | 4/12 | 7/12 |
| 2 | ES2 retained c=4 | 164.50 ± 72.22 | 0.000 | 0 | 0/12 | 2/12 |
| 2 | ES2 revalidated c=4 | 163.18 ± 72.37 | 0.000 | 0 | 0/12 | 2/12 |

## Same-c paired return comparison — preparation only

Pair each c=4 revalidated case with c=4 retained at the same map, observation seed, and noise factor. Average the two paired differences within each map, then average six maps. Negative means revalidation earned less discounted return in these matched cases. The SD is across paired map means, not a confidence interval.

| Factor | Mean return difference: revalidated − retained c=4 | Paired map SD | Map pairs |
|---|---:|---:|---:|
| 0.5 | -2.688 | 5.534 | 6 |
| 1 | -1.878 | 3.254 | 6 |
| 2 | -1.317 | 2.320 | 6 |

At matched noise, the mean extension-control difference is about −1.88 return units. Do not infer significance or equivalence by simply comparing that number with the unpaired SD bars.

## Likely professor questions

### What is your strongest result?

Confidence assumptions strongly affect the observed safety–reward trade-off. Across tested noise factors, revalidated c=4 has zero violations versus two for retained c=4. State that this is a small finite study, not a universal guarantee.

### Which comparison establishes the contribution of revalidation?

Retained c=4 versus revalidated c=4, with the same map/observation/actual noise/horizon. Source c=2 versus revalidated c=4 changes both confidence and certificate mode.

### If both c=4 methods have zero violations at factor 1, why revalidate?

That subset does not establish an extra violation reduction. The distinction appears under underestimated noise: the c=4 retained control records two unsafe actions in one run; revalidated records zero. This motivates the mechanism but is limited evidence.

### Does source c=2 win because it has higher reward?

Higher return alone does not satisfy a safety-constrained objective. Source c=2 also violates the constraint. We retain and report the actual reward/violations together instead of masking unfavorable outcomes.

### Why is the oracle higher?

It has privileged true fields. It is a reference, not a fair same-information learner and not a universal finite-horizon return upper bound.

### Why do SafeMDP and basic SNO-MDP coincide at matched noise?

Basic never reaches its switching criterion in these 160-action nominal runs, so it follows the same exploration controller as SafeMDP. This is a measured subset property; other budgets/noise can distinguish them.

### Did ES2 save total actions or computation time?

It reallocated about 42.58 actions from exploration to reward optimization in the matched c=2 comparison. Total physical actions remain 160. Both GPs keep updating, so this does not establish a runtime reduction.

### The demo switches at step 159. Why does your table say 117.42?

The saved source demo is map 100 / observation 3000, one case. The table averages 12 runs on six maps. Other cases switch earlier. That demo was selected by the first held-out map/observation rule, not for the largest stopping benefit.

### How can there be zero failed runs but 384 unsafe actions?

Failures are setup/model/planning/region-loss terminations. Unsafe actions are physical margin violations, which are scored without an evaluator-based action veto or automatic unsafe stop. They can occur in a run that still completes its horizon.

### Why do your three ES2 totals add to 100 instead of the report's 384?

The report includes all five learner conditions. SafeMDP contributes 142 and basic SNO-MDP 142, in addition to source ES2 98, confidence ES2 2, and revalidated ES2 0. Oracle adds 0. These are different scopes.

### Does zero observed violations establish safety?

No. We did not establish the paper's uniform confidence event for this practical fixed-c port. Finite maps, model assumptions, and correlated decisions limit the conclusion.

### Are your error bars confidence intervals? Does overlap mean no effect?

They are SD across six map means. They are neither standard errors nor confidence intervals. Overlap alone does not prove no difference or equivalence. A formal analysis would use the matched map hierarchy and a declared inferential procedure.

### Was c=4 chosen after seeing these results?

No. A predeclared development-data rule selected it before held-out outcomes. The development candidates tied on zero observed failure/unsafe-run rates and c=4 ranked better on the reward-ratio criterion. It did not maximize held-out nominal reward.

### Is the reward normalized? Can I compare 177.56 to the paper's Mars score?

This is raw discounted reward on our generated maps. It is not a percentage or the authors' normalized episode score. Different maps, units, horizons, and metrics prevent that direct numerical comparison.

### Where are P-ES2 and Mars results?

They are outside our implemented and frozen evaluation scope. We discuss them only as literature. Do not claim their scores or datasets as our experiments.

### What would you improve next?

Evaluate more independent terrains and noise realizations, examine kernel misspecification and failure modes, and validate on separately specified environments. A new environment or P-ES2 implementation requires new code and measured evidence, not relabeling these results.

## Sentences to use and avoid

| Use | Avoid |
|---|---|
| Zero observed violations in these 36 revalidated cases | Guaranteed zero risk |
| Source ES2 has higher nominal mean reward and more violations | Source ES2 is unconditionally the best method |
| About 42.58 actions reallocated within the fixed budget | ES2 executes 42.58 fewer actions or runs five times faster |
| Map SD describes variability | These bars are 95% confidence intervals |
| Two unsafe actions in one retained-c=4 run | Two unsafe runs or a general two-percent risk |
| Current-LCB is our labelled extension | The paper proves the safety of our exact source-profile code |

## Last-minute memory card

- 192 total; 180 learner + 12 oracle; six terrains, two observations, 160 actions.
- Factor 1: 12 runs per condition, with six map-level units.
- Nominal ES2 returns: 177.56 / 157.18 / 155.31; unsafe means: 2.500 / 0 / 0.
- All-factor ES2 totals: 98 / 2 / 0, across 36 runs per profile.
- Hold c=4 fixed for certificate handling; zero observed violations is not a proof.
- Aim to hand off around 5:40; use the remaining 20 seconds for natural pauses.

## Evidence and reproducibility

All numbers come from the saved final inventory and aggregates. No new experiment was run for this presentation.

- [Original report](report.md) and [interpretation](empirical_findings.md).
- [Every case](../results/final/runs.csv), [aggregate values](../results/final/aggregates.csv), and [frozen protocol](frozen_protocol.json).
- [Graph inputs and hashes](member3_results_assets/graph_manifest.json).
- [Machine-readable counts and paired differences](member3_results_assets/evidence.json).
- [Reward curve CSV](member3_results_assets/reward_curve_data.csv), [nominal CSV](member3_results_assets/matched_noise_results.csv), [noise CSV](member3_results_assets/noise_robustness_results.csv), [stopping CSV](member3_results_assets/stopping_results.csv).
- Rebuild with `python3 report/build_member3_results.py` from the project folder. The full team deck and frozen scientific files are not overwritten.
