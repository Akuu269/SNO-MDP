"""Standalone results deck for Member 3. Does not overwrite the full team deck."""

from collections import defaultdict
import hashlib
import html
import json

import build_team_presentation as deck
import numpy as np
from matplotlib import pyplot as plt


ROOT, REPORT = deck.ROOT, deck.REPORT
ASSETS = REPORT / "member3_results_assets"
PREFIX = "member3_results"
PROFILES = ("source", "confidence", "revalidated")
NAMES = {
    "source": "ES2 retained c=2",
    "confidence": "ES2 retained c=4",
    "revalidated": "ES2 revalidated c=4",
}


SCRIPTS = [
    """Let me connect the method to what we actually observed. We tested six generated maps, using two separate sets of noisy sensor observations on each map. Every run received 160 actions. That gives twelve runs per condition. In the first two slides, assumed sensor noise matches actual sensor noise.

The horizontal axis shows actions taken. The vertical axis shows discounted return: the reward collected, with rewards received later given slightly less weight.

The grey curve is the basic Safe Near-Optimal Markov Decision Process method, labelled SNO-MDP. The teal curve adds Early Stopping of Exploration of Safety, labelled ES2. This lets the rover switch from mapping safety to optimizing reward.

With the safety confidence multiplier set to two, the method with early stopping earns about 177.56, compared with 158.93 for the basic method. The two versions using a multiplier of four earn about 157 and 155. I will explain this multiplier next.

The dashed oracle curve knows the true environment, so it is a privileged reference.

The first observation is higher average reward with early stopping in this comparison. Let us now check whether those rewards were earned safely.""",
    """This slide puts reward and safety together. The left bars show average return. The vertical lines show standard deviation, labelled SD: how much the six map averages differ. Longer lines mean more variation between maps; they are not confidence intervals.

The right panel counts unsafe actions: moves that violate the experiment's terrain safety limit. With the safety confidence multiplier at two, the average is 2.5 per run: thirty unsafe actions across twelve runs. It is an action count, not a percentage. Both versions using a multiplier of four record zero here.

The letter c in the labels means safety confidence multiplier. It widens the uncertainty margin used to judge safety. Increasing it from two to four requires stronger evidence before allowing movement, making the rover more conservative.

The two versions at four also handle past safety decisions differently. Retained keeps earlier safety permissions. Revalidated checks them against the current model. Comparing these two holds the multiplier fixed.

Both record zero violations here, so this slide alone does not show an additional safety benefit from revalidation. Its average return is also slightly lower. The next experiment checks what happens when our noise assumption is wrong.""",
    """A rover's sensor model may underestimate measurement noise. Here we keep the actual sensor noise fixed and change only what the model assumes about altitude measurements.

On the horizontal axis, one-half means the model assumes half the actual noise standard deviation: it trusts measurements too much. One means the assumption matches reality. Two means the model assumes twice the actual noise standard deviation.

The vertical axis shows average unsafe actions per run. Across all three settings, there are thirty-six runs for each method. The totals in the side panel are ninety-eight unsafe actions with retained permissions and a multiplier of two, two with retained permissions and a multiplier of four, and zero with revalidation and a multiplier of four.

The two violations in the retained version at four occur in one run that underestimates noise. That is where the comparison separates.

Revalidation therefore records fewer violations in these tested conditions. Zero observed violations is encouraging, but six maps cannot establish safety in every environment.""",
    """The final graph shows why early stopping matters. The vertical axis counts actions spent exploring safety, and the dashed line marks our shared limit of 160 actions.

Compare the first two bars. Both use the same safety confidence multiplier of two and retain past safety permissions. The basic method spends all 160 actions exploring. With early stopping, that average falls to 117.42.

The difference is 42.58 actions, or 26.6 percent of the budget, available for reward optimization. The rover already collects rewards while exploring; early stopping changes its priority rather than switching reward collection on for the first time.

The two methods using a multiplier of four spend longer exploring, showing how conservative safety settings affect this benefit.

Every run still executes 160 actions, so this is a change in budget allocation, not evidence of faster computation. Together, the graphs show why we must assess reward, safety, and exploration together.""",
    """Thank you. Member four will now demonstrate the dashboard and show how we inspect individual runs and compare experiments.""",
]


STUDY_CONTEXT = """PURPOSE: establish a fair denominator before discussing outcomes.

192 = (5 learner conditions × 6 maps × 2 observations × 3 noise factors) + (6 maps × 2 oracle observations).
The five learners are SafeMDP, basic SNO-MDP, source ES2 c=2, retained ES2 c=4, and revalidated ES2 c=4.
The oracle appears once per map/observation pair, not once per assumed-noise factor.

Each ES2 profile has 36 runs across all noise factors and 12 at factor 1. Those 12 runs come from six
independent maps with two observation repeats per map. The 20×20 size and 160-action budget stay fixed.
Map seeds are 100–105; observation seeds are 3000 and 3001.

The source and confidence profiles retain historical certificates. The extension revalidates current
bounds, while preserving supplied initial certificates. Compare the two c=4 profiles to isolate this rule.
Development data selected c=4 before the held-out evaluation. Do not describe it as tuned on these results.

Map-mean aggregation gives each terrain equal weight. A complete experiment run is not an independent
terrain, and repeated observations/policies share information structure. Use the six maps as the
independent experimental units when discussing map variability."""


PREPARATION = [
    """PURPOSE: read the curve axes and information advantage correctly.

At step t, the curve is the mean discounted return accumulated through t physical actions. The initial
state reward is not credited as a free action: the recorded curve starts at zero. Reward is the true
arrival reward scored by the evaluator; noisy readings train the learner. All travel, stays, and
exploration moves consume the same 160-action budget and contribute their actual arrival rewards.

Discounted return is G_T = sum(t=1..T) gamma^(t-1) r(s_t), with gamma=0.99. It differs from raw cumulative
reward and from a normalized reward ratio. A score of 177.56 is not 177.56 percent and is not the paper's
Mars reward score.

Read the five curves by their labels. Grey is basic SNO-MDP c=2; teal is retained ES2 c=2; gold is retained
ES2 c=4; purple is revalidated ES2 c=4; dashed dark is oracle. This plot shows means only. Variability is
provided by the next slide. A single bend in an averaged curve is not one common ES2 switching step.

At matched noise SafeMDP and basic SNO-MDP have identical mean return here because the basic method never
switches within the 160-action horizon and uses the same exploration controller. That equality is specific
to this subset, not a universal equivalence.

The oracle has access to the true fields and uses a true-safe planning reference. It is an infinite-horizon
policy rolled out for the finite budget, so do not call it a universal finite-horizon return upper bound.""",
    """PURPOSE: explain the trade-off and avoid attributing confidence effects to the extension.

The left panel uses three ES2 conditions at factor 1. The return means are 177.5552, 157.1841, and 155.3056.
The map SDs are 80.0405, 55.9737, and 55.0548. Each SD describes six per-map means, after averaging the
two observation seeds. It is not a standard error, confidence interval, or proof of equal performance.

The right panel counts executed constraint violations, not false beliefs. Source ES2 records 30 unsafe
actions in 12 runs, so its mean is 30/12=2.5. Ten of those 12 runs have at least one violation, giving
an unsafe-run fraction of 83.33%. These quantities have different denominators. Both c=4 profiles have
zero unsafe actions at matched noise. All three complete their scheduled horizon.

Retained c=2 versus retained c=4 changes the safety multiplier while holding the certificate rule.
Retained c=4 versus revalidated c=4 changes certificate handling while holding confidence.
Retained c=2 versus revalidated c=4 changes both. Read the controls before claiming causality.

The extension's nominal mean return is about 1.88 below the c=4 retained control. We have not performed
a formal significance/equivalence test. Overlapping unpaired SD bars alone do not answer that question.
A paired analysis should compare matched maps/observations and retain the six-map hierarchy.

Zero executed violations is not automatically zero false certificates or a theorem. The actual nominal
c=4 records also show zero peak false certificates, but that extra observation must not be generalized
to arbitrary noise, kernels, or environments.""",
    """PURPOSE: show the condition where the same-c control separates from revalidation.

The actual altitude and reward sensor STDs remain 0.001. The x-axis changes the altitude GP's assumption:
factor 0.5 means assumed altitude STD 0.0005; factor 1 means 0.001; factor 2 means 0.002.
The reward GP uses the specified reward noise, without this factor.

For retained c=2 the unsafe-action totals are 58, 30, and 10 at factors 0.5, 1, and 2, giving 98 overall.
For retained c=4 they are 2, 0, and 0. For revalidated c=4 they are 0, 0, and 0.
The graph divides each factor's totals by 12 runs, so 58/12=4.8333, 30/12=2.5, and 10/12=0.8333.
The side panel gives totals across all 36 runs per profile; do not confuse those with per-run means.

Both retained-c=4 violations occur in one factor-0.5 run. This is limited evidence, not a robust estimate
of rare-event probabilities. A practical interval can be wrong; retaining an old acceptance can matter
later. Current-LCB revalidation enforces current model support, which can itself be wrong.

All 192 cases completed, with zero model/setup/planning/region-loss failures. The full inventory still
contains 384 unsafe actions because it also includes SafeMDP and basic SNO-MDP. Completion is separate
from action safety; never summarize it as 'no failures, therefore no violations.'

Next explain the exploration-budget result. Keep this plot's conclusion limited to the tested noise
conditions and practical confidence settings.""",
    """PURPOSE: explain the measured benefit of early stopping without claiming fewer total actions.

The horizontal categories are basic SNO-MDP c=2, retained ES2 c=2, retained ES2 c=4, and revalidated
ES2 c=4. The vertical axis is mean physical actions assigned to safety exploration at matched noise.
There are 12 runs per condition on six maps. The dashed line marks the common 160-action horizon.

The means are 160.00, 117.42, 149.33, and 153.75. The controlled comparison for early stopping is basic
c=2 versus retained ES2 c=2: the confidence multiplier and retained-certificate rule are held fixed.
The difference is 42.58 actions, or 26.6% of the fixed budget. The remaining actions are available for
the reward-optimization phase. Exploration and travel already earn reward, so this is not a change
from zero reward to positive reward and does not directly quantify the return gain.

Source ES2 triggers in 11/12 cases; each c=4 ES2 variant triggers in 2/12. The more conservative
confidence setting changes the stopping behavior. Do not attribute c=2-versus-c=4 differences solely
to the certificate extension. A mean is not the switching step of every individual trajectory.

Every run executes 160 physical actions. This result does not establish lower wall-clock cost, fewer
GP updates, or a five-fold speedup. Source c=2 also has violations, as shown earlier; earlier stopping
alone does not establish better constrained performance. End with the measured benefit and trade-off,
then use the separate Thank You slide to hand over to Member 4.""",
]


def load_evidence():
    summary = json.loads((ROOT / "results/final/summary.json").read_text())
    runs = json.loads((ROOT / "results/final/runs.json").read_text())
    aggregates = {
        (a["profile"], a["method"], a["noise_factor"]): a for a in summary["aggregates"]
    }
    assert summary["planned_runs"] == summary["completed_runs"] == len(runs) == 192
    assert summary["maps"] == 6 and summary["failed_runs"] == 0
    assert all(
        r["physical_actions"] == 160 and r["stop_reason"] == "horizon_reached"
        for r in runs
    )
    totals = []
    for factor in (0.5, 1, 2):
        for profile in PROFILES:
            selected = [
                r
                for r in runs
                if r["profile"] == profile
                and r["method"] == "sno_es2"
                and r["noise_factor"] == factor
            ]
            assert len(selected) == 12
            a = aggregates[profile, "sno_es2", factor]
            by_map = defaultdict(list)
            for r in selected:
                by_map[r["map_seed"]].append(r)
            assert len(by_map) == 6 and all(len(v) == 2 for v in by_map.values())
            means = [
                np.mean([r["discounted_return"] for r in values])
                for values in by_map.values()
            ]
            assert np.isclose(np.mean(means), a["discounted_return_mean"])
            assert np.isclose(np.std(means, ddof=1), a["discounted_return_map_sd"])
            totals.append(
                {
                    "profile": profile,
                    "noise_factor": factor,
                    "total_unsafe_actions": sum(r["unsafe_actions"] for r in selected),
                    "unsafe_runs": sum(r["unsafe_actions"] > 0 for r in selected),
                    "es2_triggered_runs": sum(r["es2_triggered"] for r in selected),
                    "runs": len(selected),
                    "maps": len(by_map),
                }
            )
    paired = []
    for factor in (0.5, 1, 2):
        by_case = {
            (r["map_seed"], r["observation_seed"], r["profile"]): r
            for r in runs
            if r["method"] == "sno_es2"
            and r["noise_factor"] == factor
            and r["profile"] in ("confidence", "revalidated")
        }
        differences = defaultdict(list)
        for m in range(100, 106):
            for o in (3000, 3001):
                differences[m].append(
                    by_case[m, o, "revalidated"]["discounted_return"]
                    - by_case[m, o, "confidence"]["discounted_return"]
                )
        values = [np.mean(v) for v in differences.values()]
        paired.append(
            {
                "noise_factor": factor,
                "revalidated_minus_retained_c4_mean_return": float(np.mean(values)),
                "paired_map_sd": float(np.std(values, ddof=1)),
                "map_pairs": 6,
            }
        )
    return summary, runs, aggregates, totals, paired


def scene(title, seconds, script="", prep=""):
    return deck.base(
        title,
        3,
        seconds,
        script
        + (
            "\n\nPREPARATION ONLY — NOT PART OF THE TIMED SCRIPT\n" + prep
            if prep
            else ""
        ),
    )


def stopping_chart(aggregates):
    rows = [
        ("Basic c=2", "source", "sno_basic", "basic"),
        ("ES2 retained\nc=2", "source", "sno_es2", "source"),
        ("ES2 retained\nc=4", "confidence", "sno_es2", "confidence"),
        ("ES2 revalidated\nc=4", "revalidated", "sno_es2", "revalidated"),
    ]
    with plt.rc_context({"font.size": 17, "axes.labelsize": 18}):
        fig, ax = plt.subplots(figsize=(11.3, 5.55))
        fig.subplots_adjust(left=0.1, right=0.98, bottom=0.19, top=0.9)
        deck.chart_style(ax)
        values = [
            aggregates[p, m, 1]["exploration_actions_mean"] for _, p, m, _ in rows
        ]
        ax.bar(
            range(4), values, color=[deck.COLORS[c] for _, _, _, c in rows], width=0.58
        )
        ax.set(ylim=(0, 183), ylabel="Mean safety-exploration actions")
        ax.set_xticks(range(4), [r[0] for r in rows], fontsize=16)
        for i, value in enumerate(values):
            ax.text(
                i, value + 4, f"{value:.2f}", ha="center", fontsize=18, color=deck.INK
            )
        ax.axhline(160, color="#81919a", linestyle="--", linewidth=1)
        fig.savefig(ASSETS / "result_stopping.png", dpi=180, facecolor="white")
        fig.savefig(ASSETS / "result_stopping.svg")
        plt.close(fig)
    deck.write_csv(
        ASSETS / "stopping_results.csv",
        [
            {
                "condition": label.replace("\n", " "),
                "mean_exploration_actions": aggregates[p, m, 1][
                    "exploration_actions_mean"
                ],
                "es2_fraction": aggregates[p, m, 1]["es2_triggered_mean"],
                "runs": 12,
                "maps": 6,
            }
            for label, p, m, _ in rows
        ],
    )


def build_slides(aggregates):
    scenes = []
    saved = (
        aggregates["source", "sno_basic", 1]["exploration_actions_mean"]
        - aggregates["source", "sno_es2", 1]["exploration_actions_mean"]
    )
    specs = [
        (
            "Reward across the same action budget",
            90,
            "result_reward_curves.png",
            "Read the curves",
            "Matched noise\n12 runs / condition\n6 independent maps\nγ = 0.99",
            "Means include exploration and travel reward. Oracle uses privileged true-field information.",
        ),
        (
            "Safety and reward must be read together",
            90,
            "result_matched_noise.png",
            "Same-c control",
            "Both c=4 variants:\n0 observed violations\nAt matched noise\nNo safety-proof claim",
            "Return error bars are map SD, not confidence intervals. Equal zero counts do not prove equivalence.",
        ),
        (
            "Robustness when sensor noise is misspecified",
            80,
            "result_noise_robustness.png",
            "Unsafe totals",
            "Retained c=2: 98\nRetained c=4: 2\nRevalidated c=4: 0\n36 runs / profile",
            "Revalidation records zero violations in this finite study; this is empirical evidence, not a safety proof.",
        ),
        (
            "ES2 shifts actions from exploration to reward",
            70,
            "result_stopping.png",
            "Same-c benefit",
            f"Basic vs ES2 c=2:\n{saved:.2f} actions shifted\n{100 * saved / 160:.1f}% of the budget\n160 total actions",
            "At matched noise, ES2 reallocates the fixed action budget. This does not establish a runtime speedup.",
        ),
    ]
    for i, (title, seconds, image, heading, body, caption) in enumerate(specs):
        s = scene(title, seconds, SCRIPTS[i], PREPARATION[i])
        deck.picture(s, ASSETS / image, 0.6, 2.0, 10.85, 5.05)
        deck.card(s, heading, body, 11.65, 2.2, 3.65, 4.15)
        deck.callout(
            s, caption, y=7.22, color=deck.GOLD if i == 2 else deck.PALE, size=19
        )
        deck.text(s, f"Result {i + 1} / 4", 13.35, 8.53, 1.95, 11, deck.MUTED)
        scenes.append(s)

    s = deck.Slide("Thank You", 3, 10, SCRIPTS[4])
    deck.rect(s, 0, 0, deck.WIDTH, deck.HEIGHT, deck.INK)
    deck.rect(s, 0, 0, 0.13, deck.HEIGHT, deck.TEAL)
    for value, size, y, color, bold in [
        ("Thank You", 68, 3.05, "#ffffff", True),
        ("SNO-MDP · Results and evaluation", 23, 4.55, "#c7dfdf", False),
        ("Next: live dashboard demonstration", 20, 6.15, "#c7dfdf", False),
    ]:
        width = deck.font(size, bold).getlength(value) / (4 * 72)
        deck.text(s, value, (deck.WIDTH - width) / 2, y, width + 0.1, size, color, bold)
    deck.rect(s, 7.3, 5.45, 1.4, 0.04, "#dcb36a")
    scenes.append(s)
    return scenes


def detailed_notes(scenes, aggregates, totals, paired):
    lines = [
        "# Member 3 — detailed results speaker notes",
        "",
        "Your responsibility is the experimental design, graphs, tables, and defensible conclusions. Member 4 presents the dashboard. You do not need to repeat Members 1–2's algorithm derivations.",
        "",
        "**Four results slides plus a separate Thank You slide: five slides total. The expanded explanation targets 5:40, within five to six minutes including handoff.** Use the rehearsal script for the spoken explanation; the extra material below supports preparation and questions.",
        "",
        "[Your PowerPoint](member3_results.pptx) · [PDF](member3_results.pdf) · [Browser deck](member3_results.html) · [Expanded rehearsal script](member3_results_rehearsal.md)",
        "",
        "Results slides 1–3 correspond to the team's slides 10–12. Results slide 4 adds the measured ES2 exploration-budget comparison. Study design and full tables remain here as preparation material. Slide 5 is Thank You and the dashboard handoff.",
        "",
        "## Your presentation route",
        "",
        "| Time | Slide | Main message |",
        "|---|---|---|",
        "| 0:00–1:30 | 1 — Reward trajectories | State sample counts; read axes and compare raw discounted returns |",
        "| 1:30–3:00 | 2 — Safety–reward bars | Explain standard deviation, the safety confidence multiplier, and unsafe actions |",
        "| 3:00–4:20 | 3 — Noise robustness | Explain the 98 / 2 / 0 totals and their limits |",
        "| 4:20–5:30 | 4 — Early stopping and the exploration budget | Explain the 42.58 actions reallocated within the fixed budget |",
        "| 5:30–5:40 | 5 — Thank You | Hand over to Member 4 for the dashboard |",
        "| 5:40–6:00 | Buffer | Allow for pauses while pointing at graphs |",
        "",
        "For each chart, follow **axes → conditions → observation → limitation**. Point to one feature while explaining it. Do not read every legend entry or every number.",
    ]
    pointers = [
        "Point first to the horizontal 0–160 action axis, then the return axis. Identify the dashed oracle and compare the final values of basic, source ES2, and the two c=4 variants. Do not interpret a bend as a shared phase-switch step.",
        "Point to the left error bars, explain their denominator, then move to the right panel's 2.500 / 0 / 0 values. Finish by comparing the two c=4 conditions, not only c=2 against the extension.",
        "Read the three x-axis factors as noise assumptions, not different terrains or different actual sensor noises. Explain the near-zero gold point at factor 0.5, then the side-panel totals across all factors.",
        "Point to the dashed 160-action horizon, then the basic c=2 and ES2 c=2 bars. Explain 160.00 minus 117.42 equals 42.58 actions reallocated. Briefly identify the two c=4 bars as different confidence settings, rather than treating them as the same stopping comparison.",
    ]
    takeaways = [
        "Source ES2 has higher nominal mean return here; that alone does not establish better constrained performance.",
        "At matched noise both c=4 conditions record zero violations, so this subset alone does not show an extra violation reduction from revalidation.",
        "Across tested noise factors, revalidation records zero unsafe actions versus two for the matched-c retained control; this is finite, limited evidence.",
        "In the matched c=2 comparison, ES2 reallocates 26.6% of the common action budget from safety exploration to reward optimization; this is not fewer total actions or a measured runtime speedup.",
    ]
    transitions = [
        "Reward is only one side of a safe-RL evaluation; the next graph puts it beside actual violations.",
        "The same-c methods separate under underestimated noise, which motivates the next robustness plot.",
        "The final result examines the other purpose of ES2: stopping safety exploration earlier to leave more actions for reward optimization.",
        "These results show the budget benefit alongside the safety–reward trade-off. Member 4 will now demonstrate the dashboard.",
    ]
    for i, s in enumerate(scenes[:4], 1):
        lines.extend(
            [
                "",
                f"## Slide {i} — {s.title}",
                "",
                "### Spoken explanation",
                "",
                "\n".join(
                    "> " + line if line else ">" for line in SCRIPTS[i - 1].splitlines()
                ),
                "",
                "### Where to point",
                "",
                pointers[i - 1],
                "",
                "### Detailed understanding",
                "",
                PREPARATION[i - 1],
                "",
                "### Safest conclusion",
                "",
                takeaways[i - 1],
                "",
                "### Transition",
                "",
                transitions[i - 1],
            ]
        )
    lines.extend(
        [
            "",
            "## Slide 5 — Thank You",
            "",
            "> " + SCRIPTS[4],
            "",
            "Keep the closing brief and let Member 4 begin the dashboard demonstration. Do not introduce another result on this slide.",
            "",
            "## Study context — preparation only",
            "",
            STUDY_CONTEXT,
            "",
            "## Metric dictionary — know the denominator",
            "",
            "| Metric | Meaning | Common mistake |",
            "|---|---|---|",
            "| Discounted return | True arrival rewards weighted by gamma^(t−1), including exploration/travel | Calling it a percentage or normalized score |",
            "| Cumulative reward | Unweighted sum of the same arrival rewards | Assuming it must rank policies identically to discounted return |",
            "| Unsafe actions / run | Mean number of executed movements with g(s,a) < −0.25 | Treating 2.5 as 2.5% or 2.5 unsafe runs |",
            "| Unsafe-run fraction | Fraction of runs with at least one executed violation, averaged by map | Confusing it with the number of violating actions |",
            "| Failed run | Setup/model/planning/region-loss stop rather than normal horizon completion | Assuming an unsafe move necessarily terminates the simulation |",
            "| False certificates | Evaluator-detected incorrect permissions, possibly never executed | Treating every false permission as a physical accident |",
            "| ES2 trigger fraction | Fraction of cases where the auxiliary stopping condition triggered | Treating a trigger alone as proof of better reward or safety |",
            "| Mean exploration actions | Actions assigned to safety exploration within the common budget | Describing a smaller value as less total execution or measured CPU time |",
            "| Map SD | Sample SD of six map means after averaging observation repeats | Calling it a confidence interval or SD of 192 independent trials |",
            "",
            "## Worked arithmetic you can explain",
            "",
            "### Why 192 cases?",
            "",
            "Five learner conditions × six maps × two observation seeds × three noise factors = 180 learner cases. Add 12 oracle references, once per map/observation pair, to obtain 192. A single ES2 profile has 36 cases across all factors, or 12 at matched noise.",
            "",
            "### What does 2.500 unsafe actions per run mean?",
            "",
            "At matched noise, retained c=2 ES2 records 30 violating actions in 12 runs: 30/12 = 2.5. Ten of the 12 runs have at least one violation: 10/12 = 83.33%. Both statistics are correct and measure different things.",
            "",
            "### How are the return mean and SD calculated?",
            "",
            "For each map m, average its two observation-seed returns: Y_m = (G_m,3000 + G_m,3001)/2. Then mean return = sum(Y_m)/6. Map SD = sqrt(sum((Y_m − mean)^2)/(6−1)).",
            "",
            "In this balanced study, averaging all 12 returns gives the same overall mean. It does not give the same uncertainty calculation as using six map means. Repeated policies and observations are correlated; 192 is not the sample size for a single condition.",
            "",
            "### How do the noise factors translate into GP assumptions?",
            "",
            "| Factor | Actual altitude STD | Assumed altitude STD | Interpretation |",
            "|---|---:|---:|---|",
            "| 0.5 | 0.001 | 0.0005 | Underestimate altitude measurement noise |",
            "| 1 | 0.001 | 0.001 | Correctly specified |",
            "| 2 | 0.001 | 0.002 | Overestimate altitude measurement noise |",
            "",
            "Reward noise stays correctly specified at 0.001. The factor does not resample the map or deliberately add more actual sensor noise.",
            "",
            "### How much exploration was reallocated?",
        ]
    )
    basic = aggregates["source", "sno_basic", 1]
    source = aggregates["source", "sno_es2", 1]
    saved = basic["exploration_actions_mean"] - source["exploration_actions_mean"]
    lines.extend(
        [
            "",
            f"Basic c=2 averages {basic['exploration_actions_mean']:.2f} exploration actions; source ES2 c=2 averages {source['exploration_actions_mean']:.2f}. The difference is {saved:.2f} actions, or {100 * saved / 160:.1f}% of the budget, reallocated to reward optimization on average. Every case still uses 160 physical actions. No wall-clock speedup follows from this arithmetic.",
            "",
            "Source ES2 triggers in 11/12 matched-noise cases. Each c=4 variant triggers in 2/12. Those different rates reflect different confidence/certificate conditions; compare basic c=2 with source ES2 c=2 to isolate the stopping change.",
            "",
            "## Full nominal result table — preparation only",
            "",
            "Factor 1 only. Every row has 12 runs / six maps / horizon 160. All failed-run fractions are zero.",
            "",
            "| Profile / method | Return mean ± map SD | Unsafe actions / run | Unsafe runs | ES2 triggered | Exploration actions |",
            "|---|---:|---:|---:|---:|---:|",
        ]
    )
    for a in aggregates.values():
        if a["noise_factor"] in (1, None):
            lines.append(
                f"| {a['profile']} / {a['method']} | {a['discounted_return_mean']:.2f} ± {a['discounted_return_map_sd']:.2f} | {a['unsafe_actions_mean']:.3f} | {a['unsafe_run_fraction']:.2%} | {a['es2_triggered_mean']:.2%} | {a['exploration_actions_mean']:.2f} |"
            )
    lines.extend(
        [
            "",
            "## Every ES2 noise condition — preparation only",
            "",
            "Each row has 12 runs / six maps. Read totals and unsafe-run counts separately.",
            "",
            "| Factor | ES2 profile | Return ± map SD | Unsafe / run | Unsafe actions total | Runs with violation | ES2 triggers |",
            "|---|---|---:|---:|---:|---:|---:|",
        ]
    )
    for factor in (0.5, 1, 2):
        for p in PROFILES:
            a = aggregates[p, "sno_es2", factor]
            t = next(
                t for t in totals if t["profile"] == p and t["noise_factor"] == factor
            )
            lines.append(
                f"| {factor:g} | {NAMES[p]} | {a['discounted_return_mean']:.2f} ± {a['discounted_return_map_sd']:.2f} | {a['unsafe_actions_mean']:.3f} | {t['total_unsafe_actions']} | {t['unsafe_runs']}/12 | {t['es2_triggered_runs']}/12 |"
            )
    lines.extend(
        [
            "",
            "## Same-c paired return comparison — preparation only",
            "",
            "Pair each c=4 revalidated case with c=4 retained at the same map, observation seed, and noise factor. Average the two paired differences within each map, then average six maps. Negative means revalidation earned less discounted return in these matched cases. The SD is across paired map means, not a confidence interval.",
            "",
            "| Factor | Mean return difference: revalidated − retained c=4 | Paired map SD | Map pairs |",
            "|---|---:|---:|---:|",
        ]
    )
    for p in paired:
        lines.append(
            f"| {p['noise_factor']:g} | {p['revalidated_minus_retained_c4_mean_return']:.3f} | {p['paired_map_sd']:.3f} | {p['map_pairs']} |"
        )
    lines.extend(
        [
            "",
            "At matched noise, the mean extension-control difference is about −1.88 return units. Do not infer significance or equivalence by simply comparing that number with the unpaired SD bars.",
            "",
            "## Likely professor questions",
            "",
        ]
    )
    questions = [
        (
            "What is your strongest result?",
            "Confidence assumptions strongly affect the observed safety–reward trade-off. Across tested noise factors, revalidated c=4 has zero violations versus two for retained c=4. State that this is a small finite study, not a universal guarantee.",
        ),
        (
            "Which comparison establishes the contribution of revalidation?",
            "Retained c=4 versus revalidated c=4, with the same map/observation/actual noise/horizon. Source c=2 versus revalidated c=4 changes both confidence and certificate mode.",
        ),
        (
            "If both c=4 methods have zero violations at factor 1, why revalidate?",
            "That subset does not establish an extra violation reduction. The distinction appears under underestimated noise: the c=4 retained control records two unsafe actions in one run; revalidated records zero. This motivates the mechanism but is limited evidence.",
        ),
        (
            "Does source c=2 win because it has higher reward?",
            "Higher return alone does not satisfy a safety-constrained objective. Source c=2 also violates the constraint. We retain and report the actual reward/violations together instead of masking unfavorable outcomes.",
        ),
        (
            "Why is the oracle higher?",
            "It has privileged true fields. It is a reference, not a fair same-information learner and not a universal finite-horizon return upper bound.",
        ),
        (
            "Why do SafeMDP and basic SNO-MDP coincide at matched noise?",
            "Basic never reaches its switching criterion in these 160-action nominal runs, so it follows the same exploration controller as SafeMDP. This is a measured subset property; other budgets/noise can distinguish them.",
        ),
        (
            "Did ES2 save total actions or computation time?",
            f"It reallocated about {saved:.2f} actions from exploration to reward optimization in the matched c=2 comparison. Total physical actions remain 160. Both GPs keep updating, so this does not establish a runtime reduction.",
        ),
        (
            "The demo switches at step 159. Why does your table say 117.42?",
            "The saved source demo is map 100 / observation 3000, one case. The table averages 12 runs on six maps. Other cases switch earlier. That demo was selected by the first held-out map/observation rule, not for the largest stopping benefit.",
        ),
        (
            "How can there be zero failed runs but 384 unsafe actions?",
            "Failures are setup/model/planning/region-loss terminations. Unsafe actions are physical margin violations, which are scored without an evaluator-based action veto or automatic unsafe stop. They can occur in a run that still completes its horizon.",
        ),
        (
            "Why do your three ES2 totals add to 100 instead of the report's 384?",
            "The report includes all five learner conditions. SafeMDP contributes 142 and basic SNO-MDP 142, in addition to source ES2 98, confidence ES2 2, and revalidated ES2 0. Oracle adds 0. These are different scopes.",
        ),
        (
            "Does zero observed violations establish safety?",
            "No. We did not establish the paper's uniform confidence event for this practical fixed-c port. Finite maps, model assumptions, and correlated decisions limit the conclusion.",
        ),
        (
            "Are your error bars confidence intervals? Does overlap mean no effect?",
            "They are SD across six map means. They are neither standard errors nor confidence intervals. Overlap alone does not prove no difference or equivalence. A formal analysis would use the matched map hierarchy and a declared inferential procedure.",
        ),
        (
            "Was c=4 chosen after seeing these results?",
            "No. A predeclared development-data rule selected it before held-out outcomes. The development candidates tied on zero observed failure/unsafe-run rates and c=4 ranked better on the reward-ratio criterion. It did not maximize held-out nominal reward.",
        ),
        (
            "Is the reward normalized? Can I compare 177.56 to the paper's Mars score?",
            "This is raw discounted reward on our generated maps. It is not a percentage or the authors' normalized episode score. Different maps, units, horizons, and metrics prevent that direct numerical comparison.",
        ),
        (
            "Where are P-ES2 and Mars results?",
            "They are outside our implemented and frozen evaluation scope. We discuss them only as literature. Do not claim their scores or datasets as our experiments.",
        ),
        (
            "What would you improve next?",
            "Evaluate more independent terrains and noise realizations, examine kernel misspecification and failure modes, and validate on separately specified environments. A new environment or P-ES2 implementation requires new code and measured evidence, not relabeling these results.",
        ),
    ]
    for q, a in questions:
        lines.extend([f"### {q}", "", a, ""])
    lines.extend(
        [
            "## Sentences to use and avoid",
            "",
            "| Use | Avoid |",
            "|---|---|",
            "| Zero observed violations in these 36 revalidated cases | Guaranteed zero risk |",
            "| Source ES2 has higher nominal mean reward and more violations | Source ES2 is unconditionally the best method |",
            "| About 42.58 actions reallocated within the fixed budget | ES2 executes 42.58 fewer actions or runs five times faster |",
            "| Map SD describes variability | These bars are 95% confidence intervals |",
            "| Two unsafe actions in one retained-c=4 run | Two unsafe runs or a general two-percent risk |",
            "| Current-LCB is our labelled extension | The paper proves the safety of our exact source-profile code |",
            "",
            "## Last-minute memory card",
            "",
            "- 192 total; 180 learner + 12 oracle; six terrains, two observations, 160 actions.",
            "- Factor 1: 12 runs per condition, with six map-level units.",
            "- Nominal ES2 returns: 177.56 / 157.18 / 155.31; unsafe means: 2.500 / 0 / 0.",
            "- All-factor ES2 totals: 98 / 2 / 0, across 36 runs per profile.",
            "- Hold c=4 fixed for certificate handling; zero observed violations is not a proof.",
            "- Aim to hand off around 5:40; use the remaining 20 seconds for natural pauses.",
            "",
            "## Evidence and reproducibility",
            "",
            "All numbers come from the saved final inventory and aggregates. No new experiment was run for this presentation.",
            "",
            "- [Original report](report.md) and [interpretation](empirical_findings.md).",
            "- [Every case](../results/final/runs.csv), [aggregate values](../results/final/aggregates.csv), and [frozen protocol](frozen_protocol.json).",
            "- [Graph inputs and hashes](member3_results_assets/graph_manifest.json).",
            "- [Machine-readable counts and paired differences](member3_results_assets/evidence.json).",
            "- [Reward curve CSV](member3_results_assets/reward_curve_data.csv), [nominal CSV](member3_results_assets/matched_noise_results.csv), [noise CSV](member3_results_assets/noise_robustness_results.csv), [stopping CSV](member3_results_assets/stopping_results.csv).",
            "- Rebuild with §python3 report/build_member3_results.py§ from the project folder. The full team deck and frozen scientific files are not overwritten.",
        ]
    )
    (REPORT / f"{PREFIX}_speaker_notes.md").write_text(
        "\n".join(lines).replace("§", chr(96)) + "\n"
    )


def browser_deck(scenes):
    sections = []
    for i, s in enumerate(scenes, 1):
        sections.append(
            f'<section class="slide" {"hidden" if i != 1 else ""}><img src="{ASSETS.name}/slide_{i:02d}.png" alt="{html.escape(s.title)}">'
            f"<details><summary>Speaker notes</summary><pre>{html.escape(s.notes)}</pre></details></section>"
        )
    (REPORT / f"{PREFIX}.html").write_text(
        """<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Member 3 · SNO-MDP results</title><style>body{margin:0;background:#102d36;color:#edf5f5;font:14px Arial}nav{display:flex;gap:10px;align-items:center;padding:12px;flex-wrap:wrap}button,a{background:#edf6f5;color:#145c62;border:0;border-radius:5px;padding:9px 12px;cursor:pointer;text-decoration:none}.slide{max-width:1420px;margin:auto}.slide img{width:100%;display:block}details{padding:16px 24px}pre{white-space:pre-wrap;font:14px/1.6 Arial}[hidden]{display:none!important}#position{margin-left:auto}</style>
<nav><button id="prev">← Previous</button><button id="next">Next →</button><a href="member3_results_speaker_notes.md">Detailed preparation notes</a><span id="position"></span></nav>"""
        + "".join(sections)
        + """<script>let index=0;const slides=[...document.querySelectorAll('.slide')];function show(){const n=slides.length;index=Math.max(0,Math.min(n-1,index));slides.forEach((s,i)=>s.hidden=i!==index);document.getElementById('position').textContent=(index+1)+' / '+n+' · Member 3';document.getElementById('prev').disabled=index===0;document.getElementById('next').disabled=index===n-1;}document.getElementById('next').onclick=()=>{index++;show()};document.getElementById('prev').onclick=()=>{index--;show()};document.onkeydown=e=>{if(e.target.closest('details'))return;if(e.key==='ArrowRight'){e.preventDefault();index++;show()}if(e.key==='ArrowLeft'){e.preventDefault();index--;show()}};show();</script></html>"""
    )


def main():
    ASSETS.mkdir(exist_ok=True)
    actual = {
        p.name: hashlib.sha256(p.read_bytes()).hexdigest()
        for p in (ROOT / "sno_mdp").glob("*.py")
    }
    assert (
        actual
        == json.loads((REPORT / "frozen_protocol.json").read_text())["source_sha256"]
    )
    summary, runs, aggregates, totals, paired = load_evidence()
    deck.result_charts(summary, runs, assets=ASSETS)
    stopping_chart(aggregates)
    scenes = build_slides(aggregates)
    assert len(scenes) == 5 and sum(s.seconds for s in scenes) == 340
    assert all(not s.backup for s in scenes) and scenes[-1].title == "Thank You"
    for i, s in enumerate(scenes, 1):
        for e in s.elements:
            assert (
                0 <= e["x"]
                and 0 <= e["y"]
                and e["x"] + e["w"] <= 16.02
                and e["y"] + e["h"] <= 9.02
            ), (i, e)
    title = "SNO-MDP · Member 3 results and evaluation"
    deck.powerpoint(
        scenes,
        output=REPORT / f"{PREFIX}.pptx",
        title=title,
        subject="Four results slides plus Thank You; expanded five-to-six-minute explanation",
        presenter_slot="Member 3 expanded explanation: target 5:40 including handoff, within five to six minutes. Member 4 presents the dashboard separately.",
    )
    deck.render(scenes, output=REPORT / f"{PREFIX}.pdf", assets=ASSETS, title=title)
    for stale in ASSETS.glob("slide_*.png"):
        if int(stale.stem.removeprefix("slide_")) > len(scenes):
            stale.unlink()
    browser_deck(scenes)
    detailed_notes(scenes, aggregates, totals, paired)
    evidence = {
        "summary": summary,
        "noise_condition_counts": totals,
        "paired_c4_return_differences": paired,
        "main_slides": 4,
        "total_slides": 5,
        "result_slides": 4,
        "closing_slides": 1,
        "backup_slides": 0,
        "slide_titles": [s.title for s in scenes],
        "slide_seconds": [s.seconds for s in scenes],
        "handoff_included_in_slide": 5,
        "target_seconds": 340,
        "maximum_seconds": 360,
        "corresponding_team_result_slides": [10, 11, 12],
        "full_team_deck_overwritten": False,
        "source_matches_frozen": True,
    }
    (ASSETS / "evidence.json").write_text(json.dumps(evidence, indent=2) + "\n")
    script = [
        "# Member 3 — results explanation: five to six minutes",
        "",
        "**Four results slides, followed by a separate Thank You slide. Aim for about 5:40, including brief pauses and the dashboard handoff.**",
        "",
        "Speak the paragraphs below. The italic instructions are reminders about where to point; do not read them aloud. Technical terms are explained as they first appear.",
        "",
    ]
    cues = [
        "Point to the action and return axes, then compare the ends of the grey and teal curves. Identify the dashed oracle curve.",
        "Point to the left error bars, then the unsafe-action bars on the right. Compare the two conditions with a safety confidence multiplier of four.",
        "Trace the three noise assumptions from left to right, then point to the totals in the side panel.",
        "Point to the 160-action reference line, then compare the first two bars and the 42.58-action difference.",
        "Pause, thank the audience, and hand over to Member 4.",
    ]
    elapsed = 0
    for i, s in enumerate(scenes, 1):
        end = elapsed + s.seconds
        script.extend(
            [
                f"## Slide {i} — {s.title}",
                "",
                f"*Approximate position: {elapsed // 60}:{elapsed % 60:02d}–{end // 60}:{end % 60:02d}. {cues[i - 1]}*",
                "",
                SCRIPTS[i - 1],
                "",
            ]
        )
        elapsed = end
    script.extend(
        [
            "---",
            "",
            "**Rehearsal tip:** pause after each graph's main result and give the audience a moment to look at it. Practise once aloud with a timer; the 5:40–6:00 buffer allows for those pauses.",
        ]
    )
    rehearsal = REPORT / f"{PREFIX}_rehearsal.md"
    if not rehearsal.exists():
        rehearsal.write_text("\n".join(script) + "\n")
    print(
        "Built member3_results.pptx, .pdf, .html, rehearsal script and verified evidence."
    )
    print(
        "4 results slides + Thank You = 5 total · expanded explanation: 5:40 target / 6:00 maximum."
    )


if __name__ == "__main__":
    main()
